# Handoff: Experience Filter Bar + Timeline

## Overview
The Experience page of the projektant-pata portfolio lets a visitor narrow a timeline of work / life entries. This handoff covers a redesigned **filter bar** (replacing an oversized card with wrapping rainbow pills and a stray search button) plus the **two-column timeline** it filters.

The redesign collapses everything into one compact bar:
- Row 1 — segmented scope control (All / Work / Life) with a sliding gold thumb · always-visible inline search · live `n / total` count.
- Row 2 — category tags as quiet outline chips with a colour dot · "Clear filters" that only appears when a filter is active.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes that show intended look and behavior. They are not production code to lift verbatim. Recreate them in the target codebase's existing environment (React/Vue/Svelte/Blade/Twig, whatever the portfolio actually runs on) using its established component patterns, class conventions, and state handling. If no environment exists yet, pick the framework that best fits the project and implement there. Reuse the codebase's existing tokens where they match the values listed below.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, radii, and transitions. Recreate the UI pixel-accurately; every hex, size, and duration in this doc is intentional.

## Screens / Views

### 1. Filter bar (`.exp-filterbar`)
**Purpose:** narrow the timeline by scope, free text, and category tags; report how much is left.

**Layout**
- Container: `display:grid; gap:.8rem`, padding `.8rem 1rem`, background `--c-surface`, border `1px solid --c-primary-fade` (light theme: 2px), radius `1.25rem` (`--r-card-sm`). Full content width. `margin-bottom: 2.25rem` before the timeline.
- Two rows, each `display:flex; align-items:center; flex-wrap:wrap; gap:.6rem 1rem`.
- Row 2 is separated by `border-top: 1px solid color-mix(in srgb, var(--c-primary-fade) 55%, transparent)` + `padding-top:.8rem` (no side dividers, no per-group borders).

**Components**

*Scope segmented control (`.exp-scope`)*
- `position:relative; display:inline-flex; gap:.1rem; padding:.2rem`, radius `999px`, background `--c-surface-sunken` (`#131210` dark / `#E4E0D7` light), border `1px solid color-mix(in srgb, var(--c-primary-fade) 60%, transparent)`.
- Buttons: `.35rem 1.05rem` padding, `0.875rem` / weight 600 / `letter-spacing:.08em` / uppercase, radius `999px`, transparent background, color `--c-muted`; hover → `--c-fg`; selected (`aria-pressed="true"`) → color `--c-bg` (dark text on gold).
- Thumb (`.exp-scope-thumb`): absolutely positioned `top/bottom:.2rem; left:.2rem`, background `--c-primary` (`#FACC15`), radius `999px`, sits behind the buttons (buttons are `position:relative`). Its `width` and `transform: translateX()` are set in JS from the selected button's `offsetWidth` / `offsetLeft - thumb.offsetLeft`; transition `transform .3s ease-out, width .3s ease-out`. Recompute on `resize` and after webfonts load.
- Labels: `All`, `Work`, `Life`. Single-choice.

*Search (`.exp-search`)*
- `flex:1 1 15rem; min-width:11rem; display:flex; align-items:center; gap:.5rem`, padding `.4rem .85rem`, radius `999px`, background `--c-surface-sunken`, border `1px solid transparent`; `:focus-within` → border `--c-primary`.
- Magnifier: 14×14 inline SVG, `fill:none; stroke:var(--c-muted); stroke-width:1.6` — circle `cx 6.8 cy 6.8 r 4.6` + line `10.4,10.4 → 14,14` on a `0 0 16 16` viewBox. Stroke turns `--c-primary` on focus-within.
- Input: transparent, no border, `0.875rem`, color `--c-fg`, `outline:none`; placeholder `Search titles, places, tech…` in `--c-muted`.
- **Always visible** — the old expand-from-a-circle-button behavior is removed.

*Count (`.exp-count`)*
- `margin-left:auto`, monospace (`ui-monospace, monospace`), `0.85rem`, color `--c-muted`; the number in `<b>` is `--c-primary`, weight 600. Copy: `<b>5</b> / 5 entries`.

*Tags (`.exp-tags` / `.exp-tag`)*
- Row starts with label `Tags`: `11px`, `letter-spacing:.12em`, uppercase, `--c-muted`, `margin-right:.3rem`.
- Chip: `inline-flex; align-items:center; gap:.45rem`, padding `.25rem .75rem .25rem .6rem`, radius `999px`, border `1px solid color-mix(in srgb, var(--c-primary-fade) 70%, transparent)`, transparent background, color `--c-muted`, font-size `0.85rem`, sentence case (not uppercase).
- `::before` dot: 6×6 circle filled with the tag hue `--bc`.
- Hover: text `--c-fg`, border `color-mix(in srgb, var(--bc) 55%, transparent)`.
- Selected (`aria-pressed="true"`): text `--bc`, border `color-mix(in srgb, var(--bc) 60%, transparent)`, background `color-mix(in srgb, var(--bc) 14%, transparent)`, dot gains `box-shadow: 0 0 0 3px color-mix(in srgb, var(--bc) 28%, transparent)`.
- Tag set and hues: Work `#60A5FA`, Competition `#EAB308`, Certificate `#34D399`, Education `#38BDF8`, Hardware `#F59E0B`, IT `#818CF8`. Multi-choice, **OR** semantics.

*Clear (`.exp-clear`)*
- Text button, `0.85rem`, `--c-muted`, no border/background, padding `.25rem .2rem`; hover `--c-primary`. Copy: `Clear filters`.
- Hidden at rest via `opacity:0; pointer-events:none`; revealed by `.exp-filterbar.has-filters` (opacity 1) — transition `opacity .3s ease-out`. Resets scope to All, clears tags and query.

### 2. Timeline (`#exp-grid`)
**Purpose:** show the filtered entries chronologically on a central axis.

**Layout**
- `position:relative; display:flex; align-items:flex-start; overflow-x:clip`.
- Axis `#exp-grid-line`: absolute, `left:50%; translateX(-50%)`, `top:0; bottom:0`, `width:2px`, background `--c-primary-fade`, `z-index:0`.
- Columns: `flex:1; display:flex; flex-direction:column; gap:1.5rem`. Left column `padding-right:2.5rem`; right column `padding-left:2.5rem` and `padding-top:3rem` (the stagger).
- Below `700px`: single column, axis hidden, connectors/dots hidden, right column loses its top padding.

**Card (`.exp-card`)**
- Border `1px solid --c-primary-lt` (`#FED7AA` dark / `#FBBF24` light; 2px in light), radius `1.875rem` (`--r-card`), padding `1.5rem`, background `--c-surface`, `display:flex; flex-direction:column; gap:.75rem`.
- Header: `flex; align-items:flex-start; gap:1rem`. Avatar `.exp-card-img` 48×48 circle, `linear-gradient(135deg, var(--c-primary), var(--c-primary-fade))`, dark glyph (`#1C1B17`, weight 700).
- Meta: year `0.85rem` / weight 600 / `--c-primary`; title `1.3rem` / weight 400 / `line-height 1.2`; subtitle `0.875rem` / `--c-muted`.
- Body copy: `0.875rem`, weight 200, `--c-muted`, `line-height 1.6`.
- Badges: `flex; flex-wrap:wrap; gap:.4rem`; each `.exp-badge` is `.2rem .65rem`, radius `999px`, `1px solid var(--bc)`, text `--bc`, transparent background — same hue table as the filter tags.
- Connector: `::before` a `2.5rem × 1px` line at `top:50%` reaching the axis (right side for left column, left side for right column); `::after` a 12×12 gold dot at `calc(-2.5rem - 6px)` with a `3px solid var(--c-bg)` ring, `z-index:2`.

**Empty state (`.exp-empty`)**
- Hidden by default; shown when zero matches (the grid is hidden at the same time). `padding:2.5rem 0`, centered, `0.875rem`, `--c-muted`. Copy: `No entries match those filters.` + an underlined `Reset` action that runs the same handler as Clear filters.

## Interactions & Behavior
- **Scope click** → set `aria-pressed` on the clicked button only, move the thumb, re-filter.
- **Tag click** → toggle `aria-pressed`, add/remove from the active set, re-filter.
- **Search input** → filter on every `input` event (no debounce needed at this data size; debounce ~120ms if the list is fetched).
- **Match rule per entry:** `(scope === 'all' || entry.scope === scope) && (activeTags.size === 0 || entry.tags.some(t => activeTags.has(t))) && (query === '' || entryText.includes(query))`. Tags are OR so a second tag always widens the set; query is case-insensitive substring across the card's visible text.
- **Hiding:** toggle a `.exp-hidden { display:none !important }` class on the entry — cards hide in place, the axis and stagger stay intact. When the count hits 0, hide `#exp-grid` and show `.exp-empty`.
- **Count** updates on every filter change — it is the feedback channel; never change a filter without updating it.
- **`.has-filters`** on the bar whenever scope ≠ all, any tag is active, or the query is non-empty.
- **Transitions:** all `0.3s ease-out` (`--t-fast`) — thumb transform/width, chip colour/border/background, search border, clear-button opacity.
- **Accessibility:** scope and tag chips are `<button>` with `aria-pressed`; the search icon is `aria-hidden`; the search input sits inside a `<label>`. Keyboard: buttons are natively focusable — add a visible focus ring matching `--c-primary` if the codebase doesn't already.
- **Responsive:** rows wrap; search keeps `min-width:11rem`; the count drops below the search when the row wraps (acceptable). Tags wrap freely.

## State Management
```
scope: 'all' | 'work' | 'life'      // default 'all'
activeTags: Set<string>             // default empty, OR-combined
query: string                       // default ''
derived: visibleEntries, visibleCount, hasFilters
```
- No data fetching in the prototype — entries are static markup carrying `data-scope` and `data-tags`. In the real app, entries come from the existing experience collection; map each record to `{ scope, tags[], year, title, subtitle, body, badges[] }`.
- Optional (not in the prototype): persist filter state to the URL query string so a filtered view is shareable.

## Design Tokens
Colors — dark (default) / light (`html.light`):
- `--c-primary` `#FACC15` / `#B45309`
- `--c-primary-lt` `#FED7AA` / `#FBBF24`
- `--c-primary-fade` `#605443` / `#FDE68A`
- `--c-bg` `#1C1B17` / `#F3F1EC`
- `--c-surface` `#232219` / `#FFFFFF`
- `--c-surface-sunken` `#131210` / `#E4E0D7`
- `--c-fg` `#FFFFFF` / `#1C1B17`
- `--c-muted` `#A3A3A3` / `#78716C`
- `--border-w` `1px` / `2px`

Badge / tag hues: `#60A5FA` work · `#EAB308` competition · `#34D399` certificate · `#38BDF8` education · `#F59E0B` hardware · `#818CF8` it.

Type: body **Inter** (200 / 400 / 600 / 700); display headings **Space Grotesk** (500 / 700). Sizes: `--fs-mini .85rem`, `--fs-sm .875rem`, card title `1.3rem`, micro-labels `11px`. Counts use the system monospace stack.

Radii: `--r-pill 999px`, `--r-card-sm 1.25rem`, `--r-card 1.875rem`.

Spacing: bar padding `.8rem 1rem`, bar row gap `.6rem 1rem`, grid gap `.8rem`, card padding `1.5rem`, card gap `.75rem`, column gap `1.5rem`, connector length `2.5rem`, right-column stagger `3rem`.

Transition: `--t-fast 0.3s ease-out` everywhere.

## Assets
None. The only vector is the 14px search magnifier drawn inline (circle + line, spec above). Card avatars in the prototype are letters/emoji placeholders — swap for the real logos the portfolio already ships.

## Files
- `patterns/experience-timeline.html` — the full pattern: filter bar + timeline + working filter JS + empty state. **Primary reference.**
- `components/filters.html` — the filter bar in isolation, with its state documentation and usage rules.
- `components.css` — the canonical `.exp-filterbar` / `.exp-scope` / `.exp-search` / `.exp-tag` rules (see the "Filter bar + search" block) plus the card and badge rules.
- `tokens/colors.css`, `tokens/typography.css`, `tokens/layout.css`, `tokens/fonts.css` — token definitions referenced above.
- `styles.css` — token + component entry point (`@import`s the above).
